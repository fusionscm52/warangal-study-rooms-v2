-- =====================================================
-- Warangal Study Rooms — Database Schema (v1 MVP)
-- Run this in Supabase SQL Editor, then run seed.sql
-- =====================================================

create extension if not exists "pgcrypto";

-- ------------------------------------------------
-- 1. study_centres
-- ------------------------------------------------
create table if not exists study_centres (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  description text,
  address text,
  area text not null,
  city text not null default 'Warangal',
  latitude decimal(10, 7) not null,
  longitude decimal(10, 7) not null,
  phone text,
  email text,
  price_monthly integer not null default 0,
  total_seats integer not null default 0,
  opening_time text,
  closing_time text,
  visitor_count integer not null default 0,
  viral_score integer not null default 0,
  is_featured boolean not null default false,
  is_trending boolean not null default false,
  is_viral boolean not null default false,
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create index if not exists idx_study_centres_slug on study_centres (slug);
create index if not exists idx_study_centres_area on study_centres (area);
create index if not exists idx_study_centres_status on study_centres (status);
create index if not exists idx_study_centres_visitor_count on study_centres (visitor_count desc);
create index if not exists idx_study_centres_viral_score on study_centres (viral_score desc);

-- ------------------------------------------------
-- 2. study_centre_images
-- ------------------------------------------------
create table if not exists study_centre_images (
  id uuid primary key default gen_random_uuid(),
  study_centre_id uuid not null references study_centres (id) on delete cascade,
  image_url text not null,
  display_order integer not null default 0
);

create index if not exists idx_images_centre on study_centre_images (study_centre_id);

-- ------------------------------------------------
-- 3. facilities
-- ------------------------------------------------
create table if not exists facilities (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  icon text not null
);

-- ------------------------------------------------
-- 4. study_centre_facilities (junction)
-- ------------------------------------------------
create table if not exists study_centre_facilities (
  id uuid primary key default gen_random_uuid(),
  study_centre_id uuid not null references study_centres (id) on delete cascade,
  facility_id uuid not null references facilities (id) on delete cascade,
  unique (study_centre_id, facility_id)
);

create index if not exists idx_scf_centre on study_centre_facilities (study_centre_id);
create index if not exists idx_scf_facility on study_centre_facilities (facility_id);

-- ------------------------------------------------
-- 5. amenities
-- ------------------------------------------------
create table if not exists amenities (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  icon text not null
);

-- ------------------------------------------------
-- 6. study_centre_amenities (junction)
-- ------------------------------------------------
create table if not exists study_centre_amenities (
  id uuid primary key default gen_random_uuid(),
  study_centre_id uuid not null references study_centres (id) on delete cascade,
  amenity_id uuid not null references amenities (id) on delete cascade,
  unique (study_centre_id, amenity_id)
);

create index if not exists idx_sca_centre on study_centre_amenities (study_centre_id);
create index if not exists idx_sca_amenity on study_centre_amenities (amenity_id);

-- ------------------------------------------------
-- 7. locations
-- ------------------------------------------------
create table if not exists locations (
  id uuid primary key default gen_random_uuid(),
  area text unique not null,
  city text not null default 'Warangal',
  latitude decimal(10, 7) not null,
  longitude decimal(10, 7) not null
);

-- ------------------------------------------------
-- 8. search_logs
-- ------------------------------------------------
create table if not exists search_logs (
  id uuid primary key default gen_random_uuid(),
  keyword text,
  location text,
  searched_at timestamptz not null default now()
);

-- ------------------------------------------------
-- 9. views_tracking
-- ------------------------------------------------
create table if not exists views_tracking (
  id uuid primary key default gen_random_uuid(),
  study_centre_id uuid not null references study_centres (id) on delete cascade,
  visited_at timestamptz not null default now()
);

create index if not exists idx_views_centre on views_tracking (study_centre_id);

-- ------------------------------------------------
-- RPC: atomic visitor count increment + view log
-- ------------------------------------------------
create or replace function track_study_centre_view(centre_id uuid)
returns void
language plpgsql
security definer
as $$
begin
  update study_centres
     set visitor_count = visitor_count + 1
   where id = centre_id;

  insert into views_tracking (study_centre_id) values (centre_id);
end;
$$;

-- ------------------------------------------------
-- RPC: log a search keyword
-- ------------------------------------------------
create or replace function log_search(p_keyword text, p_location text)
returns void
language plpgsql
security definer
as $$
begin
  insert into search_logs (keyword, location) values (p_keyword, p_location);
end;
$$;

-- ------------------------------------------------
-- Row Level Security
-- Public (anon) can read catalogue data; writes only via RPCs above.
-- ------------------------------------------------
alter table study_centres enable row level security;
alter table study_centre_images enable row level security;
alter table facilities enable row level security;
alter table study_centre_facilities enable row level security;
alter table amenities enable row level security;
alter table study_centre_amenities enable row level security;
alter table locations enable row level security;
alter table search_logs enable row level security;
alter table views_tracking enable row level security;

create policy "Public read active centres"
  on study_centres for select using (status = 'active');

create policy "Public read images"
  on study_centre_images for select using (true);

create policy "Public read facilities"
  on facilities for select using (true);

create policy "Public read centre facilities"
  on study_centre_facilities for select using (true);

create policy "Public read amenities"
  on amenities for select using (true);

create policy "Public read centre amenities"
  on study_centre_amenities for select using (true);

create policy "Public read locations"
  on locations for select using (true);

-- search_logs / views_tracking: no public select or direct insert.
-- Writes happen through the security-definer RPCs only.
