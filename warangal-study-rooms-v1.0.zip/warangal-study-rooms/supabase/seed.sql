-- =====================================================
-- Warangal Study Rooms — Seed Data
-- Run AFTER schema.sql
-- =====================================================

-- Facilities
insert into facilities (name, icon) values
  ('WiFi', 'wifi'),
  ('AC', 'snowflake'),
  ('CCTV', 'cctv'),
  ('Power Backup', 'zap'),
  ('Locker', 'lock'),
  ('Parking', 'car')
on conflict (name) do nothing;

-- Amenities
insert into amenities (name, icon) values
  ('Drinking Water', 'glass-water'),
  ('Charging Point', 'plug'),
  ('Silent Zone', 'volume-x'),
  ('Comfortable Chairs', 'armchair')
on conflict (name) do nothing;

-- Locations
insert into locations (area, city, latitude, longitude) values
  ('Hanamkonda', 'Warangal', 18.0106, 79.5581),
  ('Warangal', 'Warangal', 17.9784, 79.5941),
  ('Kazipet', 'Warangal', 17.9723, 79.5023)
on conflict (area) do nothing;

-- Study centres
insert into study_centres
  (name, slug, description, address, area, city, latitude, longitude, phone, email,
   price_monthly, total_seats, opening_time, closing_time,
   visitor_count, viral_score, is_featured, is_trending, is_viral, status, created_at)
values
  ('Sai Study Centre', 'sai-study-centre',
   'A calm, air-conditioned reading hall near Hanamkonda Chowrastha, popular with competitive exam aspirants. Dedicated silent zones, individual cabin seating with partitions, and staff who genuinely protect the quiet.',
   '2-5-89, Nayeem Nagar, Hanamkonda Chowrastha', 'Hanamkonda', 'Warangal', 18.0089, 79.5565,
   '+91 98490 12345', 'hello@saistudycentre.in', 1200, 80, '05:30', '23:00',
   4820, 88, true, true, true, 'active', '2026-03-02T09:00:00Z'),

  ('Vidya Reading Room', 'vidya-reading-room',
   'Family-run reading room two streets from Warangal Fort Road. Long wooden desks, generous natural light in the mornings, and an unbeatable monthly price for students preparing for group exams.',
   '11-24-33, Fort Road, Warangal', 'Warangal', 'Warangal', 17.9662, 79.6019,
   '+91 96521 44556', 'vidyareadingroom@gmail.com', 800, 50, '06:00', '22:00',
   3150, 54, false, true, false, 'active', '2026-02-11T09:00:00Z'),

  ('Focus Point Study Hall', 'focus-point-study-hall',
   'Kazipet''s most popular 24-seat-per-floor study hall, a short walk from the railway junction. Every seat has its own charging point and reading lamp; lockers available for long-term members.',
   '8-1-12, Station Road, Kazipet', 'Kazipet', 'Warangal', 17.9748, 79.5069,
   '+91 91772 88990', 'focuspointkzj@gmail.com', 1000, 72, '05:00', '23:30',
   4210, 91, true, true, true, 'active', '2026-01-19T09:00:00Z'),

  ('Aspire Library & Study Zone', 'aspire-library-study-zone',
   'A modern two-floor study zone opposite Kakatiya University gate. Reference shelves for UPSC and TSPSC material, a strict silent floor upstairs, and filtered drinking water on both floors.',
   '1-8-44, KU Cross Road, Hanamkonda', 'Hanamkonda', 'Warangal', 18.0142, 79.5702,
   '+91 90007 65432', 'aspirewarangal@outlook.com', 1500, 120, '06:00', '22:30',
   5610, 76, true, false, true, 'active', '2025-12-05T09:00:00Z'),

  ('Silent Hours Study Centre', 'silent-hours-study-centre',
   'True to its name: phones stay in lockers, footwear stays outside, and the hall stays silent. A favourite of banking and SSC aspirants around Kazipet''s Fathima Nagar.',
   '3-9-71, Fathima Nagar, Kazipet', 'Kazipet', 'Warangal', 17.9791, 79.4967,
   '+91 83280 11223', 'silenthourskzj@gmail.com', 900, 40, '05:30', '22:00',
   2380, 47, false, false, false, 'active', '2026-04-01T09:00:00Z'),

  ('Kakatiya Study Point', 'kakatiya-study-point',
   'Spacious hall near the Thousand Pillar Temple with wide desks and ergonomic chairs. Early-bird batch from 5 AM and a late-night batch till midnight during exam season.',
   '6-2-15, Temple Road, Hanamkonda', 'Hanamkonda', 'Warangal', 18.0038, 79.5610,
   '+91 99485 77665', 'kakatiyastudypoint@gmail.com', 1100, 90, '05:00', '00:00',
   3890, 69, false, true, false, 'active', '2026-03-20T09:00:00Z'),

  ('Bright Minds Reading Hall', 'bright-minds-reading-hall',
   'A compact, well-lit reading hall in the heart of Warangal city, beside Pochamma Maidan. CCTV-covered, women-friendly timings, and a small terrace break area.',
   '15-1-23, Pochamma Maidan, Warangal', 'Warangal', 'Warangal', 17.9891, 79.5876,
   '+91 70325 99887', 'brightmindswgl@gmail.com', 850, 45, '06:30', '21:30',
   1980, 38, false, false, false, 'active', '2026-05-14T09:00:00Z'),

  ('Scholars Den 24x7', 'scholars-den-24x7',
   'Warangal''s first round-the-clock study centre, near MGM Hospital junction. Biometric entry, full power backup, and separate quiet pods for night-shift study. Went viral on Instagram for its midnight study community.',
   '9-4-56, MGM Junction, Warangal', 'Warangal', 'Warangal', 17.9840, 79.5947,
   '+91 86886 33445', 'scholarsden247@gmail.com', 1800, 100, '00:00', '23:59',
   6740, 97, true, true, true, 'active', '2026-02-27T09:00:00Z'),

  ('Green Leaf Study Garden', 'green-leaf-study-garden',
   'An unusual open-plus-indoor concept in Kazipet: an AC hall wrapped around a small courtyard garden. Popular for group discussion slots in the courtyard and silent solo study inside.',
   '4-7-102, Ammavaripet, Kazipet', 'Kazipet', 'Warangal', 17.9686, 79.5121,
   '+91 95028 66778', 'greenleafkzj@gmail.com', 1300, 60, '06:00', '22:00',
   2940, 82, false, false, true, 'active', '2026-06-08T09:00:00Z'),

  ('NextGen Study Lounge', 'nextgen-study-lounge',
   'The newest addition to Hanamkonda''s study scene: standing desks, bean-bag corners for reading breaks, high-speed WiFi rated for video lectures, and app-based seat check-in.',
   '7-3-18, Subedari, Hanamkonda', 'Hanamkonda', 'Warangal', 18.0057, 79.5498,
   '+91 90593 22110', 'nextgenlounge@gmail.com', 1600, 65, '06:00', '23:00',
   1120, 73, false, true, false, 'active', '2026-07-01T09:00:00Z')
on conflict (slug) do nothing;

-- Images (Unsplash placeholders — replace with real photos in Supabase Storage)
insert into study_centre_images (study_centre_id, image_url, display_order)
select sc.id, v.url, v.ord
from study_centres sc
join (values
  ('sai-study-centre', 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=1200&q=80', 0),
  ('sai-study-centre', 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&w=1200&q=80', 1),
  ('sai-study-centre', 'https://images.unsplash.com/photo-1568667256549-094345857637?auto=format&fit=crop&w=1200&q=80', 2),
  ('vidya-reading-room', 'https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&w=1200&q=80', 0),
  ('vidya-reading-room', 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&w=1200&q=80', 1),
  ('focus-point-study-hall', 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80', 0),
  ('focus-point-study-hall', 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80', 1),
  ('aspire-library-study-zone', 'https://images.unsplash.com/photo-1568667256549-094345857637?auto=format&fit=crop&w=1200&q=80', 0),
  ('aspire-library-study-zone', 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=1200&q=80', 1),
  ('aspire-library-study-zone', 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1200&q=80', 2),
  ('silent-hours-study-centre', 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&w=1200&q=80', 0),
  ('silent-hours-study-centre', 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&w=1200&q=80', 1),
  ('kakatiya-study-point', 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1200&q=80', 0),
  ('kakatiya-study-point', 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=1200&q=80', 1),
  ('bright-minds-reading-hall', 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80', 0),
  ('bright-minds-reading-hall', 'https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&w=1200&q=80', 1),
  ('scholars-den-24x7', 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=1200&q=80', 0),
  ('scholars-den-24x7', 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80', 1),
  ('scholars-den-24x7', 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&w=1200&q=80', 2),
  ('green-leaf-study-garden', 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&w=1200&q=80', 0),
  ('green-leaf-study-garden', 'https://images.unsplash.com/photo-1568667256549-094345857637?auto=format&fit=crop&w=1200&q=80', 1),
  ('nextgen-study-lounge', 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1200&q=80', 0),
  ('nextgen-study-lounge', 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=1200&q=80', 1)
) as v(slug, url, ord) on v.slug = sc.slug;

-- Facility links
insert into study_centre_facilities (study_centre_id, facility_id)
select sc.id, f.id
from study_centres sc
join (values
  ('sai-study-centre', 'WiFi'), ('sai-study-centre', 'AC'), ('sai-study-centre', 'CCTV'), ('sai-study-centre', 'Power Backup'), ('sai-study-centre', 'Locker'),
  ('vidya-reading-room', 'WiFi'), ('vidya-reading-room', 'CCTV'), ('vidya-reading-room', 'Power Backup'),
  ('focus-point-study-hall', 'WiFi'), ('focus-point-study-hall', 'AC'), ('focus-point-study-hall', 'CCTV'), ('focus-point-study-hall', 'Power Backup'), ('focus-point-study-hall', 'Locker'), ('focus-point-study-hall', 'Parking'),
  ('aspire-library-study-zone', 'WiFi'), ('aspire-library-study-zone', 'AC'), ('aspire-library-study-zone', 'CCTV'), ('aspire-library-study-zone', 'Power Backup'), ('aspire-library-study-zone', 'Parking'),
  ('silent-hours-study-centre', 'WiFi'), ('silent-hours-study-centre', 'CCTV'), ('silent-hours-study-centre', 'Locker'),
  ('kakatiya-study-point', 'WiFi'), ('kakatiya-study-point', 'AC'), ('kakatiya-study-point', 'Power Backup'), ('kakatiya-study-point', 'Parking'),
  ('bright-minds-reading-hall', 'WiFi'), ('bright-minds-reading-hall', 'CCTV'),
  ('scholars-den-24x7', 'WiFi'), ('scholars-den-24x7', 'AC'), ('scholars-den-24x7', 'CCTV'), ('scholars-den-24x7', 'Power Backup'), ('scholars-den-24x7', 'Locker'), ('scholars-den-24x7', 'Parking'),
  ('green-leaf-study-garden', 'WiFi'), ('green-leaf-study-garden', 'AC'), ('green-leaf-study-garden', 'Power Backup'), ('green-leaf-study-garden', 'Parking'),
  ('nextgen-study-lounge', 'WiFi'), ('nextgen-study-lounge', 'AC'), ('nextgen-study-lounge', 'CCTV'), ('nextgen-study-lounge', 'Power Backup')
) as v(slug, facility) on v.slug = sc.slug
join facilities f on f.name = v.facility
on conflict do nothing;

-- Amenity links
insert into study_centre_amenities (study_centre_id, amenity_id)
select sc.id, a.id
from study_centres sc
join (values
  ('sai-study-centre', 'Drinking Water'), ('sai-study-centre', 'Charging Point'), ('sai-study-centre', 'Silent Zone'), ('sai-study-centre', 'Comfortable Chairs'),
  ('vidya-reading-room', 'Drinking Water'), ('vidya-reading-room', 'Charging Point'), ('vidya-reading-room', 'Comfortable Chairs'),
  ('focus-point-study-hall', 'Drinking Water'), ('focus-point-study-hall', 'Charging Point'), ('focus-point-study-hall', 'Silent Zone'), ('focus-point-study-hall', 'Comfortable Chairs'),
  ('aspire-library-study-zone', 'Drinking Water'), ('aspire-library-study-zone', 'Charging Point'), ('aspire-library-study-zone', 'Silent Zone'), ('aspire-library-study-zone', 'Comfortable Chairs'),
  ('silent-hours-study-centre', 'Drinking Water'), ('silent-hours-study-centre', 'Silent Zone'), ('silent-hours-study-centre', 'Comfortable Chairs'),
  ('kakatiya-study-point', 'Drinking Water'), ('kakatiya-study-point', 'Charging Point'), ('kakatiya-study-point', 'Comfortable Chairs'),
  ('bright-minds-reading-hall', 'Drinking Water'), ('bright-minds-reading-hall', 'Charging Point'), ('bright-minds-reading-hall', 'Comfortable Chairs'),
  ('scholars-den-24x7', 'Drinking Water'), ('scholars-den-24x7', 'Charging Point'), ('scholars-den-24x7', 'Silent Zone'), ('scholars-den-24x7', 'Comfortable Chairs'),
  ('green-leaf-study-garden', 'Drinking Water'), ('green-leaf-study-garden', 'Charging Point'), ('green-leaf-study-garden', 'Silent Zone'), ('green-leaf-study-garden', 'Comfortable Chairs'),
  ('nextgen-study-lounge', 'Drinking Water'), ('nextgen-study-lounge', 'Charging Point'), ('nextgen-study-lounge', 'Silent Zone'), ('nextgen-study-lounge', 'Comfortable Chairs')
) as v(slug, amenity) on v.slug = sc.slug
join amenities a on a.name = v.amenity
on conflict do nothing;
