"use client";

import { useState } from "react";
import { Search } from "lucide-react";
import { useSearch } from "@/hooks/useSearch";
import { cn } from "@/lib/utils";

interface SearchBarProps {
  size?: "large" | "compact";
  className?: string;
}

export default function SearchBar({ size = "compact", className }: SearchBarProps) {
  const { query, submitSearch } = useSearch();
  const [value, setValue] = useState(query);

  const isLarge = size === "large";

  return (
    <div
      role="search"
      className={cn(
        "flex w-full items-center gap-2 rounded-full border border-slate-200 bg-white shadow-card transition focus-within:border-brand-300 focus-within:shadow-lift",
        isLarge ? "p-2 pl-5" : "p-1.5 pl-4",
        className
      )}
    >
      <Search
        size={isLarge ? 20 : 16}
        className="shrink-0 text-brand-500"
        aria-hidden
      />
      <input
        type="search"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && submitSearch(value)}
        placeholder="Search by name, location or facility — try “AC WiFi”"
        aria-label="Search study centres by name, location or facility"
        className={cn(
          "w-full min-w-0 bg-transparent text-slate-800 placeholder:text-slate-400 focus:outline-none",
          isLarge ? "py-2 text-base" : "py-1.5 text-sm"
        )}
      />
      <button
        type="button"
        onClick={() => submitSearch(value)}
        className={cn(
          "btn-primary shrink-0",
          isLarge ? "px-7" : "px-5 py-2 text-xs"
        )}
      >
        Search
      </button>
    </div>
  );
}
