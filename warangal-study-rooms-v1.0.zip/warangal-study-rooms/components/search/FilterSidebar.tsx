"use client";

import { SlidersHorizontal, X } from "lucide-react";
import { useState } from "react";
import type { Amenity, Facility, LocationArea, SortOption } from "@/types/studyCentre";
import { useSearch } from "@/hooks/useSearch";
import { cn } from "@/lib/utils";

const SORT_OPTIONS: Array<{ value: SortOption; label: string }> = [
  { value: "trending", label: "Trending" },
  { value: "most-visited", label: "Most Visited" },
  { value: "most-viral", label: "Most Viral" },
  { value: "newest", label: "Newest" },
];

interface FilterSidebarProps {
  locations: LocationArea[];
  facilities: Facility[];
  amenities: Amenity[];
}

export default function FilterSidebar({
  locations,
  facilities,
  amenities,
}: FilterSidebarProps) {
  const search = useSearch();
  const [mobileOpen, setMobileOpen] = useState(false);

  const hasActiveFilters =
    Boolean(search.location) ||
    search.facilities.length > 0 ||
    search.amenities.length > 0;

  const toggleListValue = (key: "facility" | "amenity", value: string) => {
    const current = key === "facility" ? search.facilities : search.amenities;
    const next = current.includes(value)
      ? current.filter((v) => v !== value)
      : [...current, value];
    search.updateParams({ [key]: next });
  };

  const filtersBody = (
    <div className="space-y-7">
      <fieldset>
        <legend className="mb-3 text-sm font-semibold text-slate-900">Location</legend>
        <div className="flex flex-wrap gap-2">
          {locations.map((loc) => {
            const active = search.location === loc.area;
            return (
              <button
                key={loc.id}
                type="button"
                aria-pressed={active}
                onClick={() =>
                  search.updateParams({ location: active ? null : loc.area })
                }
                className={cn(
                  "rounded-full border px-4 py-2 text-sm font-medium transition",
                  active
                    ? "border-brand-500 bg-brand-600 text-white shadow-soft"
                    : "border-slate-200 bg-white text-slate-600 hover:border-brand-300 hover:text-brand-700"
                )}
              >
                {loc.area}
              </button>
            );
          })}
        </div>
      </fieldset>

      <fieldset>
        <legend className="mb-3 text-sm font-semibold text-slate-900">Facilities</legend>
        <div className="space-y-2">
          {facilities.map((facility) => (
            <label
              key={facility.id}
              className="flex cursor-pointer items-center gap-3 rounded-xl px-2 py-1.5 text-sm text-slate-700 hover:bg-slate-50"
            >
              <input
                type="checkbox"
                checked={search.facilities.includes(facility.name)}
                onChange={() => toggleListValue("facility", facility.name)}
                className="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-400"
              />
              {facility.name}
            </label>
          ))}
        </div>
      </fieldset>

      <fieldset>
        <legend className="mb-3 text-sm font-semibold text-slate-900">Amenities</legend>
        <div className="space-y-2">
          {amenities.map((amenity) => (
            <label
              key={amenity.id}
              className="flex cursor-pointer items-center gap-3 rounded-xl px-2 py-1.5 text-sm text-slate-700 hover:bg-slate-50"
            >
              <input
                type="checkbox"
                checked={search.amenities.includes(amenity.name)}
                onChange={() => toggleListValue("amenity", amenity.name)}
                className="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-400"
              />
              {amenity.name}
            </label>
          ))}
        </div>
      </fieldset>

      <fieldset>
        <legend className="mb-3 text-sm font-semibold text-slate-900">Sort by</legend>
        <div className="space-y-2">
          {SORT_OPTIONS.map((option) => (
            <label
              key={option.value}
              className="flex cursor-pointer items-center gap-3 rounded-xl px-2 py-1.5 text-sm text-slate-700 hover:bg-slate-50"
            >
              <input
                type="radio"
                name="sort"
                checked={search.sort === option.value}
                onChange={() => search.updateParams({ sort: option.value })}
                className="h-4 w-4 border-slate-300 text-brand-600 focus:ring-brand-400"
              />
              {option.label}
            </label>
          ))}
        </div>
      </fieldset>

      {hasActiveFilters && (
        <button
          type="button"
          onClick={() =>
            search.updateParams({ location: null, facility: [], amenity: [] })
          }
          className="flex items-center gap-1.5 text-sm font-semibold text-brand-600 hover:text-brand-700"
        >
          <X size={14} aria-hidden /> Clear all filters
        </button>
      )}
    </div>
  );

  return (
    <>
      {/* Mobile toggle */}
      <button
        type="button"
        onClick={() => setMobileOpen((v) => !v)}
        aria-expanded={mobileOpen}
        className="btn-secondary w-full lg:hidden"
      >
        <SlidersHorizontal size={16} aria-hidden />
        {mobileOpen ? "Hide filters" : "Show filters"}
        {hasActiveFilters && (
          <span className="ml-1 rounded-full bg-brand-600 px-2 py-0.5 text-[10px] font-bold text-white">
            on
          </span>
        )}
      </button>

      <aside
        aria-label="Filters"
        className={cn(
          "rounded-3xl border border-slate-100 bg-white p-6 shadow-soft",
          mobileOpen ? "block" : "hidden lg:block"
        )}
      >
        {filtersBody}
      </aside>
    </>
  );
}
