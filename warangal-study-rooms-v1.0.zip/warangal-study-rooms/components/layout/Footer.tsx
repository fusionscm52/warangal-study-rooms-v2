import Link from "next/link";
import { BookOpenText } from "lucide-react";

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-slate-100 bg-slate-50">
      <div className="container-page grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-600 to-brand-400 text-white">
              <BookOpenText size={16} aria-hidden />
            </span>
            <span className="font-display text-base font-extrabold text-slate-900">
              Warangal Study Rooms
            </span>
          </div>
          <p className="text-sm leading-relaxed text-slate-500">
            Every study centre and reading room in Warangal, Hanamkonda and
            Kazipet — searchable in one place.
          </p>
        </div>

        <div>
          <h3 className="mb-3 text-sm font-semibold text-slate-900">Discover</h3>
          <ul className="space-y-2 text-sm text-slate-500">
            <li><Link className="hover:text-brand-600" href="/study-centres">All study centres</Link></li>
            <li><Link className="hover:text-brand-600" href="/trending">Trending now</Link></li>
            <li><Link className="hover:text-brand-600" href="/map">Explore on map</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="mb-3 text-sm font-semibold text-slate-900">Locations</h3>
          <ul className="space-y-2 text-sm text-slate-500">
            <li><Link className="hover:text-brand-600" href="/study-centres?location=Hanamkonda">Hanamkonda</Link></li>
            <li><Link className="hover:text-brand-600" href="/study-centres?location=Warangal">Warangal</Link></li>
            <li><Link className="hover:text-brand-600" href="/study-centres?location=Kazipet">Kazipet</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="mb-3 text-sm font-semibold text-slate-900">For centre owners</h3>
          <p className="text-sm leading-relaxed text-slate-500">
            Want your study centre listed here? Owner listings open soon —
            watch this space.
          </p>
        </div>
      </div>
      <div className="border-t border-slate-200 py-5">
        <p className="container-page text-xs text-slate-400">
          © {new Date().getFullYear()} Warangal Study Rooms. Made for students of Warangal.
        </p>
      </div>
    </footer>
  );
}
