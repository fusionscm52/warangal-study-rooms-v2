"use client";

import { useEffect } from "react";

/**
 * Fires a single fire-and-forget view event per page load,
 * powering visitor_count and the views_tracking table.
 */
export default function ViewTracker({ centreId }: { centreId: string }) {
  useEffect(() => {
    fetch("/api/track-view", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ centreId }),
    }).catch(() => {});
  }, [centreId]);

  return null;
}
