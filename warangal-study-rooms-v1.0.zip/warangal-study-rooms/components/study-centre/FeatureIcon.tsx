import {
  Armchair,
  Car,
  Cctv,
  GlassWater,
  Lock,
  Plug,
  Snowflake,
  Sparkles,
  VolumeX,
  Wifi,
  Zap,
  type LucideIcon,
} from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  wifi: Wifi,
  snowflake: Snowflake,
  cctv: Cctv,
  zap: Zap,
  lock: Lock,
  car: Car,
  "glass-water": GlassWater,
  plug: Plug,
  "volume-x": VolumeX,
  armchair: Armchair,
};

export default function FeatureIcon({
  icon,
  size = 14,
  className,
}: {
  icon: string;
  size?: number;
  className?: string;
}) {
  const Icon = ICONS[icon] ?? Sparkles;
  return <Icon size={size} className={className} aria-hidden />;
}
