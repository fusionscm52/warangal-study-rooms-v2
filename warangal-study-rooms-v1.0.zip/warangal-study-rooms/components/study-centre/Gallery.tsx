"use client";

import { useState } from "react";
import Image from "next/image";
import { ChevronLeft, ChevronRight, ImageOff } from "lucide-react";
import type { StudyCentreImage } from "@/types/studyCentre";
import { cn } from "@/lib/utils";

export default function Gallery({
  images,
  name,
}: {
  images: StudyCentreImage[];
  name: string;
}) {
  const [index, setIndex] = useState(0);

  if (!images.length) {
    return (
      <div className="flex aspect-[16/9] items-center justify-center rounded-3xl bg-brand-50 text-brand-300">
        <ImageOff size={40} aria-hidden />
      </div>
    );
  }

  const prev = () => setIndex((i) => (i - 1 + images.length) % images.length);
  const next = () => setIndex((i) => (i + 1) % images.length);

  return (
    <div>
      <div className="relative aspect-[16/9] overflow-hidden rounded-3xl bg-brand-50 shadow-card">
        <Image
          key={images[index].id}
          src={images[index].image_url}
          alt={`${name} — photo ${index + 1} of ${images.length}`}
          fill
          priority={index === 0}
          sizes="(max-width: 1024px) 100vw, 66vw"
          className="object-cover"
        />
        {images.length > 1 && (
          <>
            <button
              type="button"
              onClick={prev}
              aria-label="Previous photo"
              className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2 text-slate-700 shadow-card transition hover:bg-white"
            >
              <ChevronLeft size={18} aria-hidden />
            </button>
            <button
              type="button"
              onClick={next}
              aria-label="Next photo"
              className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2 text-slate-700 shadow-card transition hover:bg-white"
            >
              <ChevronRight size={18} aria-hidden />
            </button>
            <span className="absolute bottom-3 right-3 rounded-full bg-slate-900/70 px-3 py-1 text-xs font-medium text-white">
              {index + 1} / {images.length}
            </span>
          </>
        )}
      </div>

      {images.length > 1 && (
        <div className="mt-3 flex gap-3 overflow-x-auto pb-1">
          {images.map((image, i) => (
            <button
              key={image.id}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={`Show photo ${i + 1}`}
              aria-current={i === index}
              className={cn(
                "relative h-16 w-24 shrink-0 overflow-hidden rounded-xl border-2 transition",
                i === index
                  ? "border-brand-500"
                  : "border-transparent opacity-70 hover:opacity-100"
              )}
            >
              <Image
                src={image.image_url}
                alt=""
                fill
                sizes="96px"
                className="object-cover"
              />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
