import type { Amenity } from "@/types/studyCentre";
import FeatureIcon from "@/components/study-centre/FeatureIcon";

export default function Amenities({ amenities }: { amenities: Amenity[] }) {
  if (!amenities.length) return null;
  return (
    <section aria-labelledby="amenities-heading">
      <h2 id="amenities-heading" className="section-heading text-xl sm:text-2xl">
        Amenities
      </h2>
      <ul className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {amenities.map((amenity) => (
          <li
            key={amenity.id}
            className="flex items-center gap-3 rounded-2xl border border-brand-100 bg-brand-50/60 px-4 py-3"
          >
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white text-brand-600 shadow-soft">
              <FeatureIcon icon={amenity.icon} size={16} />
            </span>
            <span className="text-sm font-medium text-slate-800">{amenity.name}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}
