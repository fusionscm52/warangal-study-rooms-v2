import type { Facility } from "@/types/studyCentre";
import FeatureIcon from "@/components/study-centre/FeatureIcon";

export default function Facilities({ facilities }: { facilities: Facility[] }) {
  if (!facilities.length) return null;
  return (
    <section aria-labelledby="facilities-heading">
      <h2 id="facilities-heading" className="section-heading text-xl sm:text-2xl">
        Facilities
      </h2>
      <ul className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {facilities.map((facility) => (
          <li
            key={facility.id}
            className="flex items-center gap-3 rounded-2xl border border-slate-100 bg-slate-50 px-4 py-3"
          >
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white text-brand-600 shadow-soft">
              <FeatureIcon icon={facility.icon} size={16} />
            </span>
            <span className="text-sm font-medium text-slate-800">{facility.name}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}
