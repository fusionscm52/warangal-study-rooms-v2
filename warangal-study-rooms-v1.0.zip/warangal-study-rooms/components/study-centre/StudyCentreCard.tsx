import Image from "next/image";
import Link from "next/link";
import { Armchair, Eye, Flame, MapPin, Sparkles } from "lucide-react";
import type { StudyCentre } from "@/types/studyCentre";
import { formatCount, formatPrice } from "@/lib/utils";
import FeatureIcon from "@/components/study-centre/FeatureIcon";

export default function StudyCentreCard({
  centre,
  badge,
}: {
  centre: StudyCentre;
  badge?: "trending" | "visited" | "viral";
}) {
  const cover = centre.images[0]?.image_url;

  return (
    <article className="card group flex h-full flex-col">
      <Link
        href={`/study-centre/${centre.slug}`}
        className="relative block aspect-[4/3] overflow-hidden bg-brand-50"
      >
        {cover ? (
          <Image
            src={cover}
            alt={centre.name}
            fill
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
            className="object-cover transition duration-300 group-hover:scale-105"
          />
        ) : (
          <span className="flex h-full items-center justify-center text-brand-300">
            <Armchair size={40} aria-hidden />
          </span>
        )}

        {badge === "trending" && (
          <span className="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full bg-white/95 px-3 py-1 text-xs font-semibold text-orange-600 shadow-soft">
            <Flame size={12} aria-hidden /> Trending
          </span>
        )}
        {badge === "visited" && (
          <span className="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full bg-white/95 px-3 py-1 text-xs font-semibold text-brand-700 shadow-soft">
            <Eye size={12} aria-hidden /> {formatCount(centre.visitor_count)} visits
          </span>
        )}
        {badge === "viral" && (
          <span className="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full bg-white/95 px-3 py-1 text-xs font-semibold text-violet-600 shadow-soft">
            <Sparkles size={12} aria-hidden /> Viral
          </span>
        )}
      </Link>

      <div className="flex flex-1 flex-col gap-3 p-5">
        <div>
          <h3 className="font-display text-lg font-bold text-slate-900">
            <Link
              href={`/study-centre/${centre.slug}`}
              className="hover:text-brand-600"
            >
              {centre.name}
            </Link>
          </h3>
          <p className="mt-1 flex items-center gap-1 text-sm text-slate-500">
            <MapPin size={14} className="text-brand-500" aria-hidden />
            {centre.area}, {centre.city}
          </p>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {centre.facilities.slice(0, 4).map((facility) => (
            <span key={facility.id} className="chip">
              <FeatureIcon icon={facility.icon} size={12} />
              {facility.name}
            </span>
          ))}
          {centre.facilities.length > 4 && (
            <span className="chip">+{centre.facilities.length - 4} more</span>
          )}
        </div>

        <div className="mt-auto flex items-end justify-between gap-3 border-t border-slate-100 pt-4">
          <div>
            <p className="font-display text-lg font-extrabold text-slate-900">
              {formatPrice(centre.price_monthly)}
              <span className="text-xs font-medium text-slate-400"> /month</span>
            </p>
            <p className="text-xs text-slate-500">{centre.total_seats} seats</p>
          </div>
          <Link
            href={`/study-centre/${centre.slug}`}
            className="rounded-full bg-brand-600 px-4 py-2 text-xs font-semibold text-white transition hover:bg-brand-700"
          >
            View Details
          </Link>
        </div>
      </div>
    </article>
  );
}
