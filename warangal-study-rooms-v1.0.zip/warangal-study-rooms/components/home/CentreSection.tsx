import Link from "next/link";
import { ArrowRight } from "lucide-react";
import type { StudyCentre } from "@/types/studyCentre";
import StudyCentreCard from "@/components/study-centre/StudyCentreCard";

interface CentreSectionProps {
  id: string;
  title: React.ReactNode;
  subtitle: string;
  centres: StudyCentre[];
  badge?: "trending" | "visited" | "viral";
  viewAllHref: string;
  muted?: boolean;
}

export default function CentreSection({
  id,
  title,
  subtitle,
  centres,
  badge,
  viewAllHref,
  muted,
}: CentreSectionProps) {
  if (!centres.length) return null;
  return (
    <section id={id} className={muted ? "bg-slate-50 py-16" : "py-16"}>
      <div className="container-page">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="section-heading">{title}</h2>
            <p className="mt-1 text-sm text-slate-500">{subtitle}</p>
          </div>
          <Link
            href={viewAllHref}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-brand-600 hover:text-brand-700"
          >
            View all <ArrowRight size={15} aria-hidden />
          </Link>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {centres.slice(0, 4).map((centre) => (
            <StudyCentreCard key={centre.id} centre={centre} badge={badge} />
          ))}
        </div>
      </div>
    </section>
  );
}
