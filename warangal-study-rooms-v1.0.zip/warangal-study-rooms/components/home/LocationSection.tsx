import Link from "next/link";
import { MapPin } from "lucide-react";
import type { LocationArea, StudyCentre } from "@/types/studyCentre";

export default function LocationSection({
  locations,
  centres,
}: {
  locations: LocationArea[];
  centres: StudyCentre[];
}) {
  return (
    <section className="py-16">
      <div className="container-page">
        <h2 className="section-heading">Browse by location</h2>
        <p className="mt-1 text-sm text-slate-500">
          Every study centre, organised by where you live.
        </p>
        <div className="mt-8 grid gap-6 sm:grid-cols-3">
          {locations.map((location) => {
            const count = centres.filter((c) => c.area === location.area).length;
            const fromPrice = Math.min(
              ...centres
                .filter((c) => c.area === location.area)
                .map((c) => c.price_monthly),
              Infinity
            );
            return (
              <Link
                key={location.id}
                href={`/study-centres?location=${encodeURIComponent(location.area)}`}
                className="card group flex items-center justify-between p-6"
              >
                <div>
                  <h3 className="font-display text-lg font-bold text-slate-900 group-hover:text-brand-600">
                    {location.area}
                  </h3>
                  <p className="mt-1 text-sm text-slate-500">
                    {count} {count === 1 ? "centre" : "centres"}
                    {Number.isFinite(fromPrice) && ` · from ₹${fromPrice}/mo`}
                  </p>
                </div>
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-brand-50 text-brand-600 transition group-hover:bg-brand-600 group-hover:text-white">
                  <MapPin size={18} aria-hidden />
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
