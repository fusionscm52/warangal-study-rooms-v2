import { Suspense } from "react";
import { MapPin, Users, Building2 } from "lucide-react";
import SearchBar from "@/components/search/SearchBar";

export default function Hero({
  centreCount,
  totalSeats,
}: {
  centreCount: number;
  totalSeats: number;
}) {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-brand-50 via-brand-50/40 to-white">
      <div
        aria-hidden
        className="pointer-events-none absolute -top-32 left-1/2 h-96 w-[52rem] -translate-x-1/2 rounded-full bg-gradient-to-r from-brand-200/50 via-brand-300/40 to-brand-200/50 blur-3xl"
      />
      <div className="container-page relative py-16 text-center sm:py-24">
        <span className="chip mb-6 bg-white shadow-soft">
          <MapPin size={12} aria-hidden />
          Warangal · Hanamkonda · Kazipet
        </span>
        <h1 className="mx-auto max-w-3xl font-display text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl lg:text-6xl">
          Find the Best{" "}
          <span className="bg-gradient-to-r from-brand-600 to-brand-400 bg-clip-text text-transparent">
            Study Rooms
          </span>{" "}
          in Warangal
        </h1>
        <p className="mx-auto mt-5 max-w-xl text-base text-slate-500 sm:text-lg">
          Discover silent and comfortable study spaces near you — compare
          facilities, prices and seats before you visit.
        </p>

        <div className="mx-auto mt-9 max-w-2xl">
          <Suspense fallback={<div className="h-16 rounded-full bg-white shadow-card" />}>
            <SearchBar size="large" />
          </Suspense>
        </div>

        <dl className="mx-auto mt-10 flex max-w-md items-center justify-center gap-8 text-left sm:gap-12">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-brand-600 shadow-soft">
              <Building2 size={18} aria-hidden />
            </span>
            <div>
              <dt className="text-xs text-slate-500">Study centres</dt>
              <dd className="font-display text-lg font-extrabold text-slate-900">
                {centreCount}+
              </dd>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-brand-600 shadow-soft">
              <Users size={18} aria-hidden />
            </span>
            <div>
              <dt className="text-xs text-slate-500">Seats listed</dt>
              <dd className="font-display text-lg font-extrabold text-slate-900">
                {totalSeats}+
              </dd>
            </div>
          </div>
        </dl>
      </div>
    </section>
  );
}
