import type { StudyCentre } from "@/types/studyCentre";
import { formatPrice } from "@/lib/utils";

/**
 * Marker + popup factory for study centres.
 * Blue glowing circular icon with a book glyph, per the brand spec.
 */

const MARKER_SVG = `
<svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" viewBox="0 0 56 56">
  <defs>
    <radialGradient id="glow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#3387ff" stop-opacity="0.55"/>
      <stop offset="70%" stop-color="#3387ff" stop-opacity="0.18"/>
      <stop offset="100%" stop-color="#3387ff" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="core" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#1b66f5"/>
      <stop offset="100%" stop-color="#3387ff"/>
    </linearGradient>
  </defs>
  <circle cx="28" cy="28" r="26" fill="url(#glow)"/>
  <circle cx="28" cy="28" r="14" fill="url(#core)" stroke="#ffffff" stroke-width="2.5"/>
  <text x="28" y="33" font-size="13" text-anchor="middle">&#128218;</text>
</svg>`;

export function createStudyMarkerIcon(): google.maps.Icon {
  return {
    url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(MARKER_SVG)}`,
    scaledSize: new google.maps.Size(56, 56),
    anchor: new google.maps.Point(28, 28),
  };
}

export function buildPopupHtml(centre: StudyCentre): string {
  const facilities = centre.facilities
    .slice(0, 4)
    .map(
      (f) =>
        `<span style="background:#eef6ff;color:#1450e1;border-radius:999px;padding:2px 10px;font-size:11px;font-weight:600;">${f.name}</span>`
    )
    .join(" ");

  return `
  <div style="font-family:Inter,system-ui,sans-serif;padding:14px 16px;max-width:250px;">
    <p style="margin:0;font-size:15px;font-weight:800;color:#0f172a;">${centre.name}</p>
    <p style="margin:4px 0 8px;font-size:12px;color:#64748b;">${centre.area}, ${centre.city} · ${centre.total_seats} seats · ${formatPrice(centre.price_monthly)}/mo</p>
    <div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:10px;">${facilities}</div>
    <a href="/study-centre/${centre.slug}"
       style="display:inline-block;background:linear-gradient(90deg,#1b66f5,#3387ff);color:#fff;border-radius:999px;padding:7px 16px;font-size:12px;font-weight:700;text-decoration:none;">
      View Details
    </a>
  </div>`;
}
