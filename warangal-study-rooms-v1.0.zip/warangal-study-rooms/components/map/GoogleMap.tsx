"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";
import { MapPin } from "lucide-react";
import type { StudyCentre } from "@/types/studyCentre";
import { useGoogleMaps } from "@/hooks/useGoogleMaps";
import { buildPopupHtml, createStudyMarkerIcon } from "@/components/map/StudyMarker";
import { cn } from "@/lib/utils";

const WARANGAL_CENTER = { lat: 17.9925, lng: 79.553 };

const MAP_STYLES: google.maps.MapTypeStyle[] = [
  { featureType: "poi", elementType: "labels", stylers: [{ visibility: "off" }] },
  { featureType: "transit", elementType: "labels", stylers: [{ visibility: "off" }] },
  { featureType: "water", stylers: [{ color: "#d9ecff" }] },
  { featureType: "landscape", stylers: [{ color: "#f8fafc" }] },
];

interface GoogleMapProps {
  centres: StudyCentre[];
  className?: string;
  zoom?: number;
}

export default function GoogleMap({ centres, className, zoom = 13 }: GoogleMapProps) {
  const { ready, error, hasKey } = useGoogleMaps();
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const infoWindowRef = useRef<google.maps.InfoWindow | null>(null);

  useEffect(() => {
    if (!ready || !containerRef.current) return;

    if (!mapRef.current) {
      mapRef.current = new google.maps.Map(containerRef.current, {
        center: WARANGAL_CENTER,
        zoom,
        styles: MAP_STYLES,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: true,
        clickableIcons: false,
      });
      infoWindowRef.current = new google.maps.InfoWindow();
    }

    // Reset markers on data change
    markersRef.current.forEach((m) => m.setMap(null));
    markersRef.current = [];

    const icon = createStudyMarkerIcon();
    const bounds = new google.maps.LatLngBounds();

    centres.forEach((centre) => {
      const position = { lat: centre.latitude, lng: centre.longitude };
      const marker = new google.maps.Marker({
        map: mapRef.current,
        position,
        icon,
        title: centre.name,
      });
      marker.addListener("click", () => {
        infoWindowRef.current?.setContent(buildPopupHtml(centre));
        infoWindowRef.current?.open({ map: mapRef.current, anchor: marker });
      });
      markersRef.current.push(marker);
      bounds.extend(position);
    });

    if (centres.length > 1) {
      mapRef.current.fitBounds(bounds, 48);
    } else if (centres.length === 1) {
      mapRef.current.setCenter(bounds.getCenter());
      mapRef.current.setZoom(15);
    }
  }, [ready, centres, zoom]);

  if (!hasKey || error) {
    return (
      <div
        className={cn(
          "flex flex-col items-center justify-center gap-4 rounded-3xl border border-dashed border-brand-200 bg-brand-50/50 p-8 text-center",
          className
        )}
      >
        <span className="flex h-12 w-12 items-center justify-center rounded-full bg-white text-brand-500 shadow-soft">
          <MapPin size={22} aria-hidden />
        </span>
        <div>
          <p className="font-display text-base font-bold text-slate-900">
            Map preview unavailable
          </p>
          <p className="mt-1 max-w-sm text-sm text-slate-500">
            {error ??
              "Add NEXT_PUBLIC_GOOGLE_MAPS_API_KEY to your environment to show the live Warangal map here."}
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-2">
          {centres.slice(0, 6).map((centre) => (
            <Link
              key={centre.id}
              href={`/study-centre/${centre.slug}`}
              className="chip hover:bg-brand-100"
            >
              <MapPin size={12} aria-hidden />
              {centre.name}
            </Link>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      role="application"
      aria-label="Map of study centres in Warangal"
      className={cn("rounded-3xl bg-brand-50", className)}
    />
  );
}
