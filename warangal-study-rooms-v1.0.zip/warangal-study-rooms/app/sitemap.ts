import type { MetadataRoute } from "next";
import { getStudyCentres } from "@/lib/queries";

const BASE_URL = "https://warangalstudyrooms.in";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const centres = await getStudyCentres();

  const staticPages: MetadataRoute.Sitemap = [
    { url: BASE_URL, changeFrequency: "daily", priority: 1 },
    { url: `${BASE_URL}/study-centres`, changeFrequency: "daily", priority: 0.9 },
    { url: `${BASE_URL}/map`, changeFrequency: "weekly", priority: 0.7 },
    { url: `${BASE_URL}/trending`, changeFrequency: "daily", priority: 0.8 },
  ];

  const centrePages: MetadataRoute.Sitemap = centres.map((centre) => ({
    url: `${BASE_URL}/study-centre/${centre.slug}`,
    lastModified: centre.created_at,
    changeFrequency: "weekly",
    priority: 0.8,
  }));

  return [...staticPages, ...centrePages];
}
