import Link from "next/link";
import { SearchX } from "lucide-react";

export default function NotFound() {
  return (
    <div className="container-page flex flex-col items-center justify-center gap-4 py-28 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-full bg-brand-50 text-brand-500">
        <SearchX size={26} aria-hidden />
      </span>
      <h1 className="font-display text-3xl font-extrabold text-slate-900">
        Page not found
      </h1>
      <p className="max-w-md text-slate-500">
        We couldn&apos;t find that page. It may have moved, or the study centre
        is no longer listed.
      </p>
      <Link href="/study-centres" className="btn-primary mt-2">
        Browse all study centres
      </Link>
    </div>
  );
}
