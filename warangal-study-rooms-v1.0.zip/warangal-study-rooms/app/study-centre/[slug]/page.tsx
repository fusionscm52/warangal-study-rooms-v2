import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import {
  Armchair,
  Clock,
  Eye,
  Flame,
  Mail,
  MapPin,
  Phone,
  Sparkles,
} from "lucide-react";
import Gallery from "@/components/study-centre/Gallery";
import Facilities from "@/components/study-centre/Facilities";
import Amenities from "@/components/study-centre/Amenities";
import ViewTracker from "@/components/study-centre/ViewTracker";
import GoogleMap from "@/components/map/GoogleMap";
import { getStudyCentreBySlug, getStudyCentres } from "@/lib/queries";
import { formatCount, formatPrice, formatTime } from "@/lib/utils";

export const revalidate = 300;

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  const centres = await getStudyCentres();
  return centres.map((centre) => ({ slug: centre.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const centre = await getStudyCentreBySlug(slug);
  if (!centre) return { title: "Study centre not found" };
  return {
    title: centre.name,
    description: `${centre.name} in ${centre.area}, ${centre.city} — ${
      centre.total_seats
    } seats from ${formatPrice(centre.price_monthly)}/month. ${centre.facilities
      .map((f) => f.name)
      .join(", ")}.`,
    openGraph: {
      title: `${centre.name} | Warangal Study Rooms`,
      images: centre.images[0]?.image_url
        ? [{ url: centre.images[0].image_url }]
        : undefined,
    },
  };
}

export default async function StudyCentreDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const centre = await getStudyCentreBySlug(slug);
  if (!centre) notFound();

  return (
    <div className="container-page py-10">
      <ViewTracker centreId={centre.id} />

      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="mb-6 text-sm text-slate-500">
        <ol className="flex flex-wrap items-center gap-1.5">
          <li><Link href="/" className="hover:text-brand-600">Home</Link></li>
          <li aria-hidden>/</li>
          <li><Link href="/study-centres" className="hover:text-brand-600">Study Centres</Link></li>
          <li aria-hidden>/</li>
          <li className="font-medium text-slate-900">{centre.name}</li>
        </ol>
      </nav>

      <div className="grid gap-10 lg:grid-cols-[1fr_360px]">
        {/* Main column */}
        <div className="space-y-10">
          <div>
            <div className="mb-4 flex flex-wrap items-center gap-2">
              {centre.is_trending && (
                <span className="chip bg-orange-50 text-orange-600">
                  <Flame size={12} aria-hidden /> Trending
                </span>
              )}
              {centre.is_viral && (
                <span className="chip bg-violet-50 text-violet-600">
                  <Sparkles size={12} aria-hidden /> Viral
                </span>
              )}
              <span className="chip">
                <Eye size={12} aria-hidden /> {formatCount(centre.visitor_count)} visits
              </span>
            </div>

            <h1 className="font-display text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">
              {centre.name}
            </h1>
            <p className="mt-2 flex items-center gap-1.5 text-slate-500">
              <MapPin size={16} className="text-brand-500" aria-hidden />
              {centre.address}
            </p>
          </div>

          <Gallery images={centre.images} name={centre.name} />

          <section aria-labelledby="about-heading">
            <h2 id="about-heading" className="section-heading text-xl sm:text-2xl">
              About this study centre
            </h2>
            <p className="mt-3 leading-relaxed text-slate-600">
              {centre.description}
            </p>
          </section>

          <Facilities facilities={centre.facilities} />
          <Amenities amenities={centre.amenities} />

          <section aria-labelledby="location-heading">
            <h2 id="location-heading" className="section-heading text-xl sm:text-2xl">
              Location
            </h2>
            <p className="mt-2 mb-4 text-sm text-slate-500">
              {centre.address} — {centre.area}, {centre.city}
            </p>
            <GoogleMap centres={[centre]} className="h-[340px] w-full" />
          </section>
        </div>

        {/* Sticky booking-style sidebar */}
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-3xl border border-slate-100 bg-white p-6 shadow-card">
            <p className="font-display text-3xl font-extrabold text-slate-900">
              {formatPrice(centre.price_monthly)}
              <span className="text-sm font-medium text-slate-400"> /month</span>
            </p>

            <dl className="mt-6 space-y-4 border-t border-slate-100 pt-6 text-sm">
              <div className="flex items-center gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
                  <Armchair size={16} aria-hidden />
                </span>
                <div>
                  <dt className="text-slate-500">Total seats</dt>
                  <dd className="font-semibold text-slate-900">{centre.total_seats} seats</dd>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
                  <Clock size={16} aria-hidden />
                </span>
                <div>
                  <dt className="text-slate-500">Timing</dt>
                  <dd className="font-semibold text-slate-900">
                    {formatTime(centre.opening_time)} – {formatTime(centre.closing_time)}
                  </dd>
                </div>
              </div>
            </dl>

            <div className="mt-6 space-y-3 border-t border-slate-100 pt-6">
              <a href={`tel:${centre.phone.replace(/\s+/g, "")}`} className="btn-primary w-full">
                <Phone size={15} aria-hidden /> {centre.phone}
              </a>
              <a href={`mailto:${centre.email}`} className="btn-secondary w-full">
                <Mail size={15} aria-hidden /> Email the centre
              </a>
            </div>

            <p className="mt-4 text-center text-xs text-slate-400">
              Call before visiting — seats fill fast during exam season.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}
