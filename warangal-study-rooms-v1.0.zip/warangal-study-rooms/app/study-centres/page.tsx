import type { Metadata } from "next";
import { Suspense } from "react";
import { SearchX } from "lucide-react";
import SearchBar from "@/components/search/SearchBar";
import FilterSidebar from "@/components/search/FilterSidebar";
import StudyCentreCard from "@/components/study-centre/StudyCentreCard";
import {
  getAmenities,
  getFacilities,
  getLocations,
  searchStudyCentres,
} from "@/lib/queries";
import type { SortOption } from "@/types/studyCentre";

export const metadata: Metadata = {
  title: "Study Centres in Warangal, Hanamkonda & Kazipet",
  description:
    "Search and filter every study centre and reading room in Warangal by location, facilities, amenities and price.",
};

interface PageProps {
  searchParams: Promise<{
    q?: string;
    location?: string;
    facility?: string | string[];
    amenity?: string | string[];
    sort?: string;
  }>;
}

const toArray = (v?: string | string[]) =>
  v === undefined ? [] : Array.isArray(v) ? v : [v];

const VALID_SORTS: SortOption[] = [
  "trending",
  "most-visited",
  "most-viral",
  "newest",
];

export default async function StudyCentresPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const sort = VALID_SORTS.includes(params.sort as SortOption)
    ? (params.sort as SortOption)
    : "trending";

  const [results, locations, facilities, amenities] = await Promise.all([
    searchStudyCentres({
      query: params.q,
      location: params.location,
      facilities: toArray(params.facility),
      amenities: toArray(params.amenity),
      sort,
    }),
    getLocations(),
    getFacilities(),
    getAmenities(),
  ]);

  return (
    <div className="container-page py-10">
      <div className="mb-8 max-w-2xl">
        <h1 className="section-heading text-3xl sm:text-4xl">
          Study centres{params.location ? ` in ${params.location}` : " in Warangal"}
        </h1>
        <p className="mt-2 text-slate-500">
          {results.length} {results.length === 1 ? "centre" : "centres"}
          {params.q ? ` matching “${params.q}”` : " listed"} — filter by
          location, facilities and amenities.
        </p>
      </div>

      <div className="mb-8 max-w-2xl">
        <Suspense fallback={<div className="h-14 rounded-full bg-slate-50" />}>
          <SearchBar />
        </Suspense>
      </div>

      <div className="grid gap-8 lg:grid-cols-[280px_1fr]">
        <Suspense fallback={<div className="rounded-3xl bg-slate-50 lg:h-96" />}>
          <FilterSidebar
            locations={locations}
            facilities={facilities}
            amenities={amenities}
          />
        </Suspense>

        {results.length ? (
          <div className="grid content-start gap-6 sm:grid-cols-2 xl:grid-cols-3">
            {results.map((centre) => (
              <StudyCentreCard key={centre.id} centre={centre} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center gap-3 rounded-3xl bg-slate-50 p-14 text-center">
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-white text-slate-400 shadow-soft">
              <SearchX size={22} aria-hidden />
            </span>
            <p className="font-display text-lg font-bold text-slate-900">
              No centres match those filters
            </p>
            <p className="max-w-sm text-sm text-slate-500">
              Try removing a facility filter or searching a different area —
              Hanamkonda, Warangal and Kazipet all have listed centres.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
