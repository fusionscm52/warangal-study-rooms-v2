import type { Metadata } from "next";
import "./globals.css";
import Navbar from "@/components/navbar/Navbar";
import Footer from "@/components/layout/Footer";

export const metadata: Metadata = {
  metadataBase: new URL("https://warangalstudyrooms.in"),
  title: {
    default: "Warangal Study Rooms | Find Study Centres Near You",
    template: "%s | Warangal Study Rooms",
  },
  description:
    "Discover silent and comfortable study spaces in Warangal, Hanamkonda and Kazipet. Compare facilities, prices and seats — then visit.",
  keywords: [
    "study rooms Warangal",
    "study centres Hanamkonda",
    "reading rooms Kazipet",
    "library Warangal",
    "study space Telangana",
  ],
  openGraph: {
    title: "Warangal Study Rooms | Find Study Centres Near You",
    description:
      "Discover silent and comfortable study spaces in Warangal, Hanamkonda and Kazipet.",
    type: "website",
    locale: "en_IN",
    siteName: "Warangal Study Rooms",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&family=Inter:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="flex min-h-screen flex-col">
        <Navbar />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
