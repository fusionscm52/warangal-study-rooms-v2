import { NextResponse } from "next/server";
import { getSupabase, isSupabaseConfigured } from "@/lib/supabase";

export async function POST(request: Request) {
  try {
    const { centreId } = await request.json();
    if (!centreId || typeof centreId !== "string") {
      return NextResponse.json({ error: "centreId is required" }, { status: 400 });
    }

    if (isSupabaseConfigured) {
      const { error } = await getSupabase().rpc("track_study_centre_view", {
        centre_id: centreId,
      });
      if (error) throw error;
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("[track-view]", err);
    // Analytics must never break the page
    return NextResponse.json({ ok: false }, { status: 200 });
  }
}
