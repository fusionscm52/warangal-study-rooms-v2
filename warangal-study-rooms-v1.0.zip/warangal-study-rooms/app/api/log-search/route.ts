import { NextResponse } from "next/server";
import { getSupabase, isSupabaseConfigured } from "@/lib/supabase";

export async function POST(request: Request) {
  try {
    const { keyword, location } = await request.json();
    const cleanKeyword =
      typeof keyword === "string" ? keyword.trim().slice(0, 120) : null;
    const cleanLocation =
      typeof location === "string" ? location.trim().slice(0, 60) : null;

    if (!cleanKeyword) {
      return NextResponse.json({ error: "keyword is required" }, { status: 400 });
    }

    if (isSupabaseConfigured) {
      const { error } = await getSupabase().rpc("log_search", {
        p_keyword: cleanKeyword,
        p_location: cleanLocation,
      });
      if (error) throw error;
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("[log-search]", err);
    return NextResponse.json({ ok: false }, { status: 200 });
  }
}
