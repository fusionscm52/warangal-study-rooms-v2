import type { Metadata } from "next";
import { Flame } from "lucide-react";
import StudyCentreCard from "@/components/study-centre/StudyCentreCard";
import { getTrendingStudyCentres } from "@/lib/queries";

export const revalidate = 300;

export const metadata: Metadata = {
  title: "Trending Study Centres",
  description:
    "The study centres students in Warangal, Hanamkonda and Kazipet are talking about right now.",
};

export default async function TrendingPage() {
  const trending = await getTrendingStudyCentres(24);

  return (
    <div className="container-page py-12">
      <div className="mb-10 max-w-2xl">
        <h1 className="section-heading inline-flex items-center gap-2 text-3xl sm:text-4xl">
          Trending Study Centres
          <Flame className="text-orange-500" size={28} aria-hidden />
        </h1>
        <p className="mt-2 text-slate-500">
          Ranked by buzz: the reading rooms Warangal students are recommending
          to each other this week.
        </p>
      </div>

      {trending.length ? (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {trending.map((centre) => (
            <StudyCentreCard key={centre.id} centre={centre} badge="trending" />
          ))}
        </div>
      ) : (
        <p className="rounded-3xl bg-slate-50 p-10 text-center text-slate-500">
          No trending centres yet — check back soon.
        </p>
      )}
    </div>
  );
}
