import Link from "next/link";
import { ArrowRight, Flame } from "lucide-react";
import Hero from "@/components/home/Hero";
import CentreSection from "@/components/home/CentreSection";
import LocationSection from "@/components/home/LocationSection";
import GoogleMap from "@/components/map/GoogleMap";
import {
  getLocations,
  getMostViral,
  getMostVisited,
  getStudyCentres,
  getTrendingStudyCentres,
} from "@/lib/queries";

export const revalidate = 300;

export default async function HomePage() {
  const [centres, trending, mostVisited, mostViral, locations] =
    await Promise.all([
      getStudyCentres(),
      getTrendingStudyCentres(4),
      getMostVisited(4),
      getMostViral(4),
      getLocations(),
    ]);

  const totalSeats = centres.reduce((sum, c) => sum + c.total_seats, 0);

  return (
    <>
      <Hero centreCount={centres.length} totalSeats={totalSeats} />

      {/* Map discovery */}
      <section className="py-16" aria-labelledby="map-heading">
        <div className="container-page">
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 id="map-heading" className="section-heading">
                Explore Warangal on the map
              </h2>
              <p className="mt-1 text-sm text-slate-500">
                Tap a marker to preview seats, price and facilities.
              </p>
            </div>
            <Link
              href="/map"
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-brand-600 hover:text-brand-700"
            >
              Full-screen map <ArrowRight size={15} aria-hidden />
            </Link>
          </div>
          <GoogleMap centres={centres} className="h-[420px] w-full sm:h-[480px]" />
        </div>
      </section>

      <CentreSection
        id="trending"
        title={
          <span className="inline-flex items-center gap-2">
            Trending Study Centres
            <Flame className="text-orange-500" size={24} aria-hidden />
          </span>
        }
        subtitle="What students in Warangal are talking about this week."
        centres={trending}
        badge="trending"
        viewAllHref="/study-centres?sort=trending"
        muted
      />

      <CentreSection
        id="most-visited"
        title="Most Visited"
        subtitle="Proven favourites, ranked by real visits."
        centres={mostVisited}
        badge="visited"
        viewAllHref="/study-centres?sort=most-visited"
      />

      <CentreSection
        id="most-viral"
        title="Most Viral"
        subtitle="The centres blowing up on social media right now."
        centres={mostViral}
        badge="viral"
        viewAllHref="/study-centres?sort=most-viral"
        muted
      />

      <LocationSection locations={locations} centres={centres} />
    </>
  );
}
