import type { Metadata } from "next";
import GoogleMap from "@/components/map/GoogleMap";
import { getStudyCentres } from "@/lib/queries";

export const revalidate = 300;

export const metadata: Metadata = {
  title: "Study Centre Map",
  description:
    "Explore every study centre in Warangal, Hanamkonda and Kazipet on an interactive map.",
};

export default async function MapPage() {
  const centres = await getStudyCentres();

  return (
    <div className="container-page py-12">
      <div className="mb-8 max-w-2xl">
        <h1 className="section-heading text-3xl sm:text-4xl">
          Explore study centres on the map
        </h1>
        <p className="mt-2 text-slate-500">
          {centres.length} centres across Warangal. Tap any glowing marker to
          preview seats, price and facilities.
        </p>
      </div>
      <GoogleMap
        centres={centres}
        className="h-[65vh] min-h-[420px] w-full"
      />
    </div>
  );
}
