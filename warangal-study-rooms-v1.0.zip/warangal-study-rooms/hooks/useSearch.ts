"use client";

import { useCallback } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";

/**
 * Central hook for reading and writing search state in the URL.
 * Keeping filters in the URL makes every result set shareable and SEO-friendly.
 */
export function useSearch() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const query = searchParams.get("q") ?? "";
  const location = searchParams.get("location") ?? "";
  const facilities = searchParams.getAll("facility");
  const amenities = searchParams.getAll("amenity");
  const sort = searchParams.get("sort") ?? "trending";

  const updateParams = useCallback(
    (updates: Record<string, string | string[] | null>) => {
      const params = new URLSearchParams(searchParams.toString());
      Object.entries(updates).forEach(([key, value]) => {
        params.delete(key);
        if (value === null) return;
        if (Array.isArray(value)) {
          value.forEach((v) => params.append(key, v));
        } else if (value) {
          params.set(key, value);
        }
      });
      const qs = params.toString();
      router.push(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
    },
    [router, pathname, searchParams]
  );

  const submitSearch = useCallback(
    (rawQuery: string) => {
      const q = rawQuery.trim();
      const params = new URLSearchParams(searchParams.toString());
      if (q) params.set("q", q);
      else params.delete("q");
      router.push(`/study-centres${params.size ? `?${params}` : ""}`);

      // Fire-and-forget analytics
      if (q) {
        fetch("/api/log-search", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ keyword: q, location: location || null }),
        }).catch(() => {});
      }
    },
    [router, searchParams, location]
  );

  return {
    query,
    location,
    facilities,
    amenities,
    sort,
    updateParams,
    submitSearch,
  };
}
