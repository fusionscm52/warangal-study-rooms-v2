"use client";

import { useMemo } from "react";
import type { StudyCentre } from "@/types/studyCentre";

/**
 * Derives ranked views (trending / most visited / most viral) from a
 * server-provided list of study centres, without extra network requests.
 */
export function useStudyCentres(centres: StudyCentre[]) {
  return useMemo(() => {
    const trending = centres
      .filter((c) => c.is_trending)
      .sort((a, b) => b.viral_score - a.viral_score);
    const mostVisited = [...centres].sort(
      (a, b) => b.visitor_count - a.visitor_count
    );
    const mostViral = centres
      .filter((c) => c.is_viral || c.viral_score >= 70)
      .sort((a, b) => b.viral_score - a.viral_score);
    return { centres, trending, mostVisited, mostViral };
  }, [centres]);
}
