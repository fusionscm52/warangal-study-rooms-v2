"use client";

import { useEffect, useState } from "react";

const CALLBACK_NAME = "__wsrMapsReady";

declare global {
  interface Window {
    [CALLBACK_NAME]?: () => void;
    google?: typeof google;
  }
}

/**
 * Loads the Google Maps JavaScript API exactly once and reports readiness.
 * Returns { ready, error, hasKey }.
 */
export function useGoogleMaps() {
  const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!apiKey) return;

    if (window.google?.maps) {
      setReady(true);
      return;
    }

    const existing = document.querySelector<HTMLScriptElement>(
      "script[data-wsr-maps]"
    );
    if (existing) {
      const onReady = () => setReady(true);
      if (window.google?.maps) onReady();
      else existing.addEventListener("load", onReady);
      return () => existing.removeEventListener("load", onReady);
    }

    window[CALLBACK_NAME] = () => setReady(true);

    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&callback=${CALLBACK_NAME}`;
    script.async = true;
    script.defer = true;
    script.dataset.wsrMaps = "true";
    script.onerror = () => setError("Google Maps failed to load.");
    document.head.appendChild(script);
  }, [apiKey]);

  return { ready, error, hasKey: Boolean(apiKey) };
}
