import { getSupabase, isSupabaseConfigured } from "@/lib/supabase";
import {
  DEMO_AMENITIES,
  DEMO_FACILITIES,
  DEMO_LOCATIONS,
  DEMO_STUDY_CENTRES,
} from "@/lib/demo-data";
import type {
  Amenity,
  Facility,
  LocationArea,
  SearchFilters,
  StudyCentre,
} from "@/types/studyCentre";

/**
 * All reads go through this module.
 * When Supabase env vars are missing (local demo), bundled demo data is used
 * so the app runs immediately. In production with env vars set, all data
 * comes from Supabase PostgreSQL.
 */

const SELECT_FULL = `
  *,
  images:study_centre_images ( id, image_url, display_order ),
  facilities:study_centre_facilities ( facility:facilities ( id, name, icon ) ),
  amenities:study_centre_amenities ( amenity:amenities ( id, name, icon ) )
`;

/* eslint-disable @typescript-eslint/no-explicit-any */
function mapRow(row: any): StudyCentre {
  return {
    ...row,
    latitude: Number(row.latitude),
    longitude: Number(row.longitude),
    images: (row.images ?? [])
      .slice()
      .sort((a: any, b: any) => a.display_order - b.display_order),
    facilities: (row.facilities ?? [])
      .map((j: any) => j.facility)
      .filter(Boolean),
    amenities: (row.amenities ?? []).map((j: any) => j.amenity).filter(Boolean),
  };
}
/* eslint-enable @typescript-eslint/no-explicit-any */

async function fetchAllFromSupabase(): Promise<StudyCentre[]> {
  const { data, error } = await getSupabase()
    .from("study_centres")
    .select(SELECT_FULL)
    .eq("status", "active");
  if (error) throw error;
  return (data ?? []).map(mapRow);
}

async function getAll(): Promise<StudyCentre[]> {
  if (!isSupabaseConfigured) return DEMO_STUDY_CENTRES;
  try {
    return await fetchAllFromSupabase();
  } catch (err) {
    console.error("[queries] Supabase read failed, serving demo data:", err);
    return DEMO_STUDY_CENTRES;
  }
}

export async function getStudyCentres(): Promise<StudyCentre[]> {
  const all = await getAll();
  return [...all].sort((a, b) => b.visitor_count - a.visitor_count);
}

export async function getStudyCentreBySlug(
  slug: string
): Promise<StudyCentre | null> {
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await getSupabase()
        .from("study_centres")
        .select(SELECT_FULL)
        .eq("slug", slug)
        .eq("status", "active")
        .maybeSingle();
      if (error) throw error;
      return data ? mapRow(data) : null;
    } catch (err) {
      console.error("[queries] getStudyCentreBySlug failed:", err);
    }
  }
  return DEMO_STUDY_CENTRES.find((c) => c.slug === slug) ?? null;
}

export async function getTrendingStudyCentres(limit = 8): Promise<StudyCentre[]> {
  const all = await getAll();
  return all
    .filter((c) => c.is_trending)
    .sort((a, b) => b.viral_score - a.viral_score)
    .slice(0, limit);
}

export async function getMostVisited(limit = 8): Promise<StudyCentre[]> {
  const all = await getAll();
  return [...all].sort((a, b) => b.visitor_count - a.visitor_count).slice(0, limit);
}

export async function getMostViral(limit = 8): Promise<StudyCentre[]> {
  const all = await getAll();
  return all
    .filter((c) => c.is_viral || c.viral_score >= 70)
    .sort((a, b) => b.viral_score - a.viral_score)
    .slice(0, limit);
}

export async function getFeatured(limit = 4): Promise<StudyCentre[]> {
  const all = await getAll();
  return all.filter((c) => c.is_featured).slice(0, limit);
}

export async function getLocations(): Promise<LocationArea[]> {
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await getSupabase().from("locations").select("*");
      if (error) throw error;
      if (data?.length) {
        return data.map((l) => ({
          ...l,
          latitude: Number(l.latitude),
          longitude: Number(l.longitude),
        }));
      }
    } catch (err) {
      console.error("[queries] getLocations failed:", err);
    }
  }
  return DEMO_LOCATIONS;
}

export async function getFacilities(): Promise<Facility[]> {
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await getSupabase()
        .from("facilities")
        .select("*")
        .order("name");
      if (error) throw error;
      if (data?.length) return data;
    } catch (err) {
      console.error("[queries] getFacilities failed:", err);
    }
  }
  return DEMO_FACILITIES;
}

export async function getAmenities(): Promise<Amenity[]> {
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await getSupabase()
        .from("amenities")
        .select("*")
        .order("name");
      if (error) throw error;
      if (data?.length) return data;
    } catch (err) {
      console.error("[queries] getAmenities failed:", err);
    }
  }
  return DEMO_AMENITIES;
}

/**
 * Real search across name, area, city, facilities, and amenities.
 *
 * Multi-word queries are tokenised and every token must match somewhere:
 * "AC WiFi" returns only centres that have BOTH AC and WiFi.
 * "Hanamkonda" returns all centres in Hanamkonda.
 */
export async function searchStudyCentres(
  filters: SearchFilters
): Promise<StudyCentre[]> {
  const all = await getAll();
  const tokens = (filters.query ?? "")
    .toLowerCase()
    .split(/\s+/)
    .map((t) => t.trim())
    .filter(Boolean);

  let results = all.filter((centre) => {
    // Location filter (exact area)
    if (filters.location && centre.area !== filters.location) return false;

    // Facility checkboxes — centre must have every selected facility
    if (filters.facilities?.length) {
      const names = centre.facilities.map((f) => f.name.toLowerCase());
      if (!filters.facilities.every((f) => names.includes(f.toLowerCase())))
        return false;
    }

    // Amenity checkboxes — centre must have every selected amenity
    if (filters.amenities?.length) {
      const names = centre.amenities.map((a) => a.name.toLowerCase());
      if (!filters.amenities.every((a) => names.includes(a.toLowerCase())))
        return false;
    }

    // Free-text tokens — every token must match name, area, city,
    // a facility, or an amenity
    if (tokens.length) {
      const haystackFields = [
        centre.name.toLowerCase(),
        centre.area.toLowerCase(),
        centre.city.toLowerCase(),
        centre.address.toLowerCase(),
        ...centre.facilities.map((f) => f.name.toLowerCase()),
        ...centre.amenities.map((a) => a.name.toLowerCase()),
      ];
      const matchesToken = (token: string) =>
        haystackFields.some((field) => field.includes(token));
      if (!tokens.every(matchesToken)) return false;
    }

    return true;
  });

  switch (filters.sort) {
    case "most-visited":
      results = results.sort((a, b) => b.visitor_count - a.visitor_count);
      break;
    case "most-viral":
      results = results.sort((a, b) => b.viral_score - a.viral_score);
      break;
    case "newest":
      results = results.sort(
        (a, b) =>
          new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      );
      break;
    case "trending":
    default:
      results = results.sort((a, b) => {
        const t = Number(b.is_trending) - Number(a.is_trending);
        return t !== 0 ? t : b.viral_score - a.viral_score;
      });
  }

  return results;
}
