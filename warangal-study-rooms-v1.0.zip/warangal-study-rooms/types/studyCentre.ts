export interface Facility {
  id: string;
  name: string;
  icon: string;
}

export interface Amenity {
  id: string;
  name: string;
  icon: string;
}

export interface StudyCentreImage {
  id: string;
  image_url: string;
  display_order: number;
}

export interface StudyCentre {
  id: string;
  name: string;
  slug: string;
  description: string;
  address: string;
  area: string;
  city: string;
  latitude: number;
  longitude: number;
  phone: string;
  email: string;
  price_monthly: number;
  total_seats: number;
  opening_time: string;
  closing_time: string;
  visitor_count: number;
  viral_score: number;
  is_featured: boolean;
  is_trending: boolean;
  is_viral: boolean;
  status: string;
  created_at: string;
  images: StudyCentreImage[];
  facilities: Facility[];
  amenities: Amenity[];
}

export interface LocationArea {
  id: string;
  area: string;
  city: string;
  latitude: number;
  longitude: number;
}

export type SortOption = "trending" | "most-visited" | "most-viral" | "newest";

export interface SearchFilters {
  query?: string;
  location?: string;
  facilities?: string[];
  amenities?: string[];
  sort?: SortOption;
}
